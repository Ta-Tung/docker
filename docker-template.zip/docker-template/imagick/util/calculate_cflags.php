<?php

// Run with something like:
// export CLFAGS=$(php util/calculate_cflags.php "8.0" "7.0.1-0")
// where the first number is the PHP version, and the second number
// is the ImageMagick version number

if ($argc !== 3) {
    fwrite(STDERR, "usage php calculate_cflags.php \$PHP_VERSION \$IMAGEMAGICK_VERSION \n");
    exit(-1);
}

$PHP_VERSION = $argv[1];
$IMAGEMAGICK_VERSION = $argv[2];

$message = sprintf(
    "Calculating for PHP_VERSION [%s] IMAGEMAGICK_VERSION [%s]\n",
    $PHP_VERSION,
    $IMAGEMAGICK_VERSION
);
fwrite(STDERR, $message);

$CFLAGS = array(
    "-Wno-deprecated-declarations",
    "-Wdeclaration-after-statement",
    "-Werror",
    "-Wall",
    "-Wextra",
    "-Wimplicit-function-declaration",
    "-Wno-variadic-macros",
    "-Wno-sign-compare",

    //Errors in IM6.9.2-0
    "-Wno-unused-parameter",
    "-Wno-unused-variable"
);


if (strpos($IMAGEMAGICK_VERSION, "6.8") === 0) {
    $CFLAGS = array("-Wno-deprecated-declarations");
}


if ($PHP_VERSION == "5.4" || $PHP_VERSION == "5.5") {
    $CFLAGS = array("-Wno-deprecated-declarations");
}
else if ($PHP_VERSION == "5.6") {
    $CFLAGS = array(
        "-Wno-deprecated-declarations",
        "-Wdeclaration-after-statement",
        "-Werror",
        "-Wall",
        "-Wimplicit-function-declaration"
    );
}

$result = implode(" ", $CFLAGS);
echo $result;
fwrite(STDERR, "Ok. CFLAGS are: $result\n");
